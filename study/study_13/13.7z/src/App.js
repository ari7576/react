import React from 'react'
import './App.css';
import {Route, Routes} from 'react-router-dom';

import About from "./pages/About";
import Home from './pages/Home';

const App = () => {
    return (
        <div>
            <Routes>
                <Route path="/" component={Home} exact={true}/>
                <Route path="/about" component={About} />
            </Routes>
        </div>
    );
};

export default App;
