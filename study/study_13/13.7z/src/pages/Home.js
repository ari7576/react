import React from 'react';

const Home = () => {
    return(
        <div>
            <h1>홈</h1>
            <p>홈, 그페이지는 가정 먼저 보여지는 페이지</p>
        </div>
    )
}

export default Home;