
import './App.css';
import Counter from './conponents/Counter'
import Todos from "./conponents/Todos";

function App() {
  return (
    <div>
        <Counter number={0}></Counter>
        <hr/>
        <Todos/>
    </div>
  );
}

export default App;
