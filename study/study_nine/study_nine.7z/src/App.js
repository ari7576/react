import logo from './logo.svg';
import './App.css';
import SassComponent from "./SassComponent";

function App() {
  return (
    <SassComponent/>
  );
}

export default App;
