import React from "react";

const Input = (props) => {
    return (
        <>
            <h3>버튼 페이지 입니다</h3>
        </>
    );
}

export default Input